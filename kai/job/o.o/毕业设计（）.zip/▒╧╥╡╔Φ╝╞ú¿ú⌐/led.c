#include<reg52.h>  	       //���ļ�
#define uchar unsigned char//�궨���޷����ַ���
#define uint unsigned int  //�궨���޷�������

#define DUAN P0	  //P0�ڿ��ƶ�
#define WEI  P2	  //P2�ڿ���λ
sbit sz=P1^0;// ����Сʱ����
sbit jia=P1^1;// ���ķ��Ӱ���
sbit jian=P1^2;// �����밴��
sbit LS138A = P2^0;  	//����138������������A����P2.2���� 
sbit LS138B = P2^1;	    //����138�������������B��P2.3����
sbit LS138C = P2^2; 	//����138�������������C��P2.4����
sbit feep=P3^7;
uint f,c=0,v=0,kk=0,hh=0,gg=0;
/********************************************************************
                            ��ʼ����
*********************************************************************/
 uchar Table[11]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x40};//�߶����Ӧֵ
 uint miao=0,fen,shi,smiao,sshi,sfen,dshi=0,dfen=0,yy=0;
void delay(uchar t)
{
  uchar i,j;
   for(i=0;i<t;i++)
   {
   	 for(j=13;j>0;j--);
	 { ;
	 }
   }
}
//************************************************
//��ʱ��������12MHz�ľ���Ƶ����
//��Լ50ms����ʱ
//************************************************
void delay_50ms(uint t)
{
	uint j;
	for(;t>0;t--)
	for(j=6245;j>0;j--);
}
void xians()
{
   
P0=0x00;
LS138A=1; 
LS138B=1; 
LS138C=1;
P0=Table[shi/10];
     delay(80);  

P0=0x00;
LS138A=0; 
LS138B=1; 
LS138C=1;
P0=Table[shi%10];	   
    delay(80);
	   P0=0x00;
LS138A=1; 
LS138B=0; 
LS138C=1;
P0=Table[10];
	 delay(80);
	   P0=0x00;
LS138A=0; 
LS138B=0; 
LS138C=1;
P0=Table[fen/10];
    delay(80);
	   P0=0x00;
LS138A=1; 
LS138B=1; 
LS138C=0;
P0=Table[fen%10];
	 delay(80);
	   P0=0x00;
LS138A=0; 
LS138B=1; 
LS138C=0;
P0=Table[10];
	 delay(80);
	   P0=0x00;
LS138A=1; 
LS138B=0; 
LS138C=0;
P0=Table[miao/10];
	  delay(80);
	   P0=0x00;
LS138A=0; 
LS138B=0; 
LS138C=0;
P0=Table[miao%10];
	   delay(80);
}
//����ʱ��
void shez()
{
c++;
P0=0x00;
LS138A=1; 
LS138B=1; 
LS138C=1;
if(hh==1)
{
if(c<=25)
{
  P0=Table[sshi/10];
}
else if(c>25&&c<=50)
{
   P0=0x00;
}
else  if(c>50)
{
   c=0;
}
}
else if(hh==2||hh==3||hh==4)
{
    P0=Table[sshi/10];
}
//P0=Table[sshi/10];
 delay(80);  
P0=0x00;
LS138A=0; 
LS138B=1; 
LS138C=1;
if(hh==2)
{
if(c<=25)
{
 P0=Table[sshi%10];	
}
else if(c>25&&c<=50)
{
    P0=0x00;
}
else if(c>50)
{
c=0;
}
}
else if(hh==1||hh==3||hh==4)
{
  P0=Table[sshi%10];	 
}   
 delay(80);  
	   P0=0x00;
LS138A=1; 
LS138B=0; 
LS138C=1;
P0=Table[10];
 delay(80);  
	   P0=0x00;
LS138A=0; 
LS138B=0; 
LS138C=1;
if(hh==3)
{
if(c<=25)
{
P0=Table[sfen/10];
}
else if(c>25&&c<=50)
{
    P0=0x00;
}
else if(c>50)
{
c=0;
}
}
else if(hh==1||hh==2||hh==4)
{
  P0=Table[sfen/10];	 
} 
 delay(80);  
	   P0=0x00;
LS138A=1; 
LS138B=1; 
LS138C=0;
if(hh==4)
{
if(c<=25)
{
P0=Table[sfen%10];
}
else if(c>25&&c<=50)
{
    P0=0x00;
}
else if(c>50)
{
c=0;
}
}
else if(hh==1||hh==2||hh==3)
{
 P0=Table[sfen%10]; 	 
} 
 delay(80);  
	   P0=0x00;
LS138A=0; 
LS138B=1; 
LS138C=0;
P0=Table[10];
 delay(80);  
	   P0=0x00;
LS138A=1; 
LS138B=0; 
LS138C=0;
P0=Table[smiao/10];
 delay(80);  
	   P0=0x00;
LS138A=0; 
LS138B=0; 
LS138C=0;
P0=Table[smiao%10];
 delay(80);  	 
}
//��ʱʱ��
void dings()
{
v++;
P0=0x00;
LS138A=1; 
LS138B=1; 
LS138C=1;
if(hh==5)
{
if(v<=25)
{
  P0=Table[dshi/10];
}
else if(v>25&&v<=50)
{
   P0=0x00;
}
else  if(v>50)
{
   v=0;
}
}
else if(hh==6||hh==7||hh==8)
{
    P0=Table[dshi/10];
}
//P0=Table[sshi/10];
 delay(80);  
P0=0x00;
LS138A=0; 
LS138B=1; 
LS138C=1;
if(hh==6)
{
if(v<=25)
{
 P0=Table[dshi%10];	
}
else if(v>25&&v<=50)
{
    P0=0x00;
}
else if(v>50)
{
v=0;
}
}
else if(hh==5||hh==7||hh==8)
{
  P0=Table[dshi%10];	 
}   
 delay(80);  
	   P0=0x00;
LS138A=1; 
LS138B=0; 
LS138C=1;
P0=Table[10];
 delay(80);  
	   P0=0x00;
LS138A=0; 
LS138B=0; 
LS138C=1;
if(hh==7)
{
if(v<=25)
{
P0=Table[dfen/10];
}
else if(v>25&&v<=50)
{
    P0=0x00;
}
else if(v>50)
{
v=0;
}
}
else if(hh==5||hh==6||hh==8)
{
  P0=Table[dfen/10];	 
} 
 delay(80);  
	   P0=0x00;
LS138A=1; 
LS138B=1; 
LS138C=0;
if(hh==8)
{
if(v<=25)
{
P0=Table[dfen%10];
}
else if(v>25&&v<=50)
{
    P0=0x00;
}
else if(v>50)
{
v=0;
}
}
else if(hh==5||hh==6||hh==7)
{
 P0=Table[dfen%10]; 	 
} 
 delay(80);  
	   P0=0x00;
LS138A=0; 
LS138B=1; 
LS138C=0;
P0=Table[10];
 delay(80);  
	   P0=0x00;
LS138A=1; 
LS138B=0; 
LS138C=0;
P0=Table[smiao/10];
 delay(80);  
	   P0=0x00;
LS138A=0; 
LS138B=0; 
LS138C=0;
P0=Table[smiao%10];
 delay(80);  	 
}
/********************************************************************
                           ��������
*********************************************************************/        

void key()//����
{
  if(sz==0)
  {
 hh++;
 
 if(hh==1)
 {
 sshi=shi;
 sfen=fen;
 }
 else if(hh>=9)
 {
 shi=sshi;
 fen=sfen;
   hh=0;
 }
    while(sz==0);
  }
  if(jia==0)
  {
	 if(sshi<14&&hh==1)
	 {
   	sshi=sshi+10; 	 
	 }
	 else if(hh==2&&sshi<24)
	 {
	 sshi++;
	 }
	 else if(hh==3&&sfen<50)
	 {
	 sfen=sfen+10;
	 }
	 else if(hh==4&&sfen<60)
	 {
	 sfen++;
	 }
	 else	 if(dshi<14&&hh==5)
	 {
   	dshi=dshi+10; 	 
	 }
	 else if(hh==6&&dshi<24)
	 {
	 dshi++;
	 }
	 else if(hh==7&&dfen<50)
	 {
	 dfen=dfen+10;
	 }
	 else if(hh==8&&dfen<60)
	 {
	 dfen++;
	 }
	 while(jia==0);
  }
    if(jian==0)
  {
	 if(sshi>10&&hh==1)
	 {
   	sshi=sshi-10; 	 
	 }
	 else if(hh==2&&sshi>0)
	 {
	 sshi--;
	 }
	 else if(hh==3&&sfen>10)
	 {
	 sfen=sfen-10;
	 }
	 else if(hh==4&&sfen>0)
	 {
	 sfen--;
	 }
	 else	 if(dshi>10&&hh==5)
	 {
   	dshi=dshi-10; 	 
	 }
	 else if(hh==6&&dshi>0)
	 {
	dshi--;
	 }
	 else if(hh==7&&dfen>10)
	 {
	 dfen=dfen-10;
	 }
	 else if(hh==8&&dfen>0)
	 {
	 dfen--;
	 }
	 while(jian==0);
  }
}



/********************************************************************
                           �жϳ�ʼ��
*********************************************************************/

void cshh()
{ 
 TMOD=0X01;//���嶨ʱ��������ʽ
	TH0=(65536-50000)/256; //���ó�ֵ	// 50000
	TL0=(65536-50000)%256;
	EA=1;      //�����жϿ���
	ET0=1;     //�򿪶�ʱ���ж�
	TR0=1;	   //�رն�ʱ��0
 }
 
/********************************************************************
                            ������
*********************************************************************/

main()
{
feep=0;
cshh();	 //�жϳ�ʼ��

while(1)
{
 key();//��������
 if(hh==0)
 {
 xians();
 }
 else if(hh==1||hh==2||hh==3||hh==4)
 {
  shez();
 }
 else if(hh==5||hh==6||hh==7||hh==8)
 {
   dings();
 }
  if(dshi==shi&&dfen==fen&&yy==1)
  {
  feep=1;
 delay_50ms(10);
  feep=0;
    delay_50ms(10);
	  feep=1;
     delay_50ms(10);
	   feep=0;
  delay_50ms(10);
	  feep=1;
     delay_50ms(10);
	   feep=0;
	   
  }
	if(gg==1)
	{
			   feep=1;
			   delay_50ms(20);
			   feep=0;
			   gg=0;	
	}
}
}
/********************************************************************
                           ��ʱ���жϺ���
*********************************************************************/

void timer0 () interrupt 1
{ 

	TH0=(65536-50000)/256; //���ó�ֵ
	TL0=(65536-50000)%256;
  kk++;
 if(kk>=20)
   {
   kk=0;
    miao++;//���1
     if(miao>=60)
       {miao=0;//������
	     fen++;//60���ּ�1
		yy=1;
	       if(fen>=60)
	        {fen=0;//������
	           shi++;//60�ֺ�ʱ��1
				gg=1;
	             if(shi>=24)
				 {
	                   shi=0;//ʱ����				 
				 }

					          }
	                           }
							   
                                  
}
}
/********************************************************************
                              ����
*********************************************************************/


